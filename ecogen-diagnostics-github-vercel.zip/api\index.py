"""EcoGen Diagnostics API, served as a Vercel Python function."""

from __future__ import annotations

import re

import pandas as pd
from flask import Flask, jsonify, request
from werkzeug.exceptions import HTTPException, RequestEntityTooLarge


app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024  # 4 MiB

LOCUS_COLUMN = re.compile(r"^Locus(\d+)_A([12])$")


def _find_locus_pairs(df: pd.DataFrame) -> list[tuple[int, str, str]]:
    """Return complete diploid locus columns in numeric locus order."""
    columns_by_locus: dict[int, dict[int, str]] = {}

    for column in df.columns:
        match = LOCUS_COLUMN.fullmatch(str(column))
        if match is None:
            # Individual_ID and any other metadata columns are not genotypes.
            continue
        locus_number = int(match.group(1))
        allele_number = int(match.group(2))
        columns_by_locus.setdefault(locus_number, {})[allele_number] = str(column)

    if not columns_by_locus:
        raise ValueError(
            "No genotype markers found. Name allele columns like Locus1_A1 and Locus1_A2."
        )

    pairs: list[tuple[int, str, str]] = []
    incomplete: list[str] = []
    for locus_number, alleles in sorted(columns_by_locus.items()):
        if 1 not in alleles or 2 not in alleles:
            missing = "A1" if 1 not in alleles else "A2"
            incomplete.append(f"Locus{locus_number}_{missing}")
            continue
        pairs.append((locus_number, alleles[1], alleles[2]))

    if incomplete:
        raise ValueError(
            "Every locus needs both allele columns. Missing: " + ", ".join(incomplete)
        )
    return pairs


def analyze_genetic_bottleneck(df: pd.DataFrame) -> dict:
    """Compute Ho, He, Fis, and the requested screening classification.

    Missing genotype calls are omitted pairwise, per locus. Ho and He are
    averaged across loci with equal weight. Fis is then computed from those
    global averages, as specified in the project brief.
    """
    if not isinstance(df, pd.DataFrame):
        raise ValueError("The uploaded data could not be read as a table.")
    if df.empty:
        raise ValueError("The CSV contains a header but no individual rows.")

    loci = _find_locus_pairs(df)
    ho_by_locus: list[float] = []
    he_by_locus: list[float] = []

    for locus_number, allele_1_column, allele_2_column in loci:
        allele_1 = df[allele_1_column].astype("string").str.strip().replace("", pd.NA)
        allele_2 = df[allele_2_column].astype("string").str.strip().replace("", pd.NA)
        complete = allele_1.notna() & allele_2.notna()

        if not complete.any():
            raise ValueError(
                f"Locus{locus_number} has no complete genotype calls; remove it or add data."
            )

        observed_1 = allele_1.loc[complete]
        observed_2 = allele_2.loc[complete]
        ho_by_locus.append(float((observed_1 != observed_2).mean()))

        pooled_alleles = pd.concat([observed_1, observed_2], ignore_index=True)
        frequencies = pooled_alleles.value_counts(normalize=True, dropna=True)
        he_by_locus.append(float(1.0 - (frequencies.pow(2).sum())))

    ho = sum(ho_by_locus) / len(ho_by_locus)
    he = sum(he_by_locus) / len(he_by_locus)
    fis = (he - ho) / he if he > 0 else None

    if ho > he:
        status = "CRITICAL"
        color = "red"
        verdict = {
            "title": "Bottleneck screening signal",
            "description": (
                "Observed heterozygosity exceeds expected heterozygosity. Under this "
                "screening rule, that pattern is interpreted as consistent with a "
                "recent demographic crash in which low-frequency rare alleles may "
                "have been lost faster than overall heterozygosity. This heuristic "
                "alone cannot confirm a bottleneck."
            ),
        }
    elif fis is not None and fis > 0.15:
        status = "WARNING"
        color = "yellow"
        verdict = {
            "title": "Inbreeding and isolation risk",
            "description": (
                "The positive Fis value is above 0.15, indicating high homozygosity "
                "relative to the Hardy–Weinberg expectation. Review possible "
                "inbreeding, habitat isolation, population structure, and genotyping "
                "issues."
            ),
        }
    else:
        status = "STABLE"
        color = "green"
        verdict = {
            "title": "No elevated signal under this screen",
            "description": (
                "Under this screen, the population is classified as being in "
                "genetic equilibrium with standard evolutionary variation levels. "
                "This threshold-based result cannot establish equilibrium or rule "
                "out conservation concerns."
            ),
        }

    return {
        "ho": ho,
        "he": he,
        "fis": fis,
        "samples_count": int(len(df.index)),
        "loci_count": int(len(loci)),
        "status": status,
        "status_text": status,
        "verdict": verdict,
        "color": color,
    }


@app.errorhandler(RequestEntityTooLarge)
def handle_file_too_large(_error):
    return jsonify({"error": "The CSV is larger than the 4 MiB upload limit."}), 413


@app.errorhandler(Exception)
def handle_unexpected_error(error):
    if isinstance(error, HTTPException):
        return jsonify({"error": error.description}), error.code
    app.logger.exception("Unhandled EcoGen Diagnostics API error")
    return jsonify({"error": "The analysis service encountered an unexpected error. Check the Vercel Function Logs."}), 500


@app.route("/api/health", methods=["GET"])
def health_check():
    return jsonify({"ok": True, "service": "EcoGen Diagnostics"})


@app.route("/api/upload", methods=["POST"])
def upload_and_analyze():
    uploaded_file = request.files.get("file")
    if uploaded_file is None or not uploaded_file.filename:
        return jsonify({"error": "Choose a CSV file to analyze."}), 400
    if not uploaded_file.filename.lower().endswith(".csv"):
        return jsonify({"error": "Only .csv files are supported."}), 400

    try:
        dataframe = pd.read_csv(uploaded_file.stream, dtype="string", encoding="utf-8-sig")
    except (pd.errors.EmptyDataError, pd.errors.ParserError, UnicodeDecodeError, ValueError) as exc:
        return jsonify({"error": f"Could not read this CSV: {exc}"}), 400

    try:
        result = analyze_genetic_bottleneck(dataframe)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    return jsonify(result)
